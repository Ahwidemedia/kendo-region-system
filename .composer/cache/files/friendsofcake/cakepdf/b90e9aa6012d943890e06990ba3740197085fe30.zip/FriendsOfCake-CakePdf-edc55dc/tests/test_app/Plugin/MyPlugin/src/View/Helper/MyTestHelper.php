<?php

namespace MyPlugin\View\Helper;

use Cake\View\Helper;

class MyTestHelper extends Helper
{

    public function dummyMethod()
    {
        return true;
    }
}
